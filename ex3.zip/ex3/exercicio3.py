import math

#----------------------------------------------------
# FUNÇÕES PARA CADA PROBLEMA
#----------------------------------------------------

def problema1_notas():
    """Lê duas notas, calcula a soma e informa a situação do aluno."""
    print("\n--- Problema 1: Notas  ---")
    try:
        nota1 = float(input("Digite a primeira nota: "))
        nota2 = float(input("Digite a segunda nota: "))
        nota_final = nota1 + nota2
        print(f"NOTA FINAL = {nota_final:.1f}")
        if nota_final < 60.0:
            print("REPROVADO")
    except ValueError:
        print("Entrada inválida. Por favor, digite números.")

def problema2_bhaskara():
    """Calcula as raízes de uma equação de segundo grau."""
    print("\n--- Problema 2: Fórmula de Bhaskara  ---")
    try:
        a = float(input("Coeficiente a: "))
        b = float(input("Coeficiente b: "))
        c = float(input("Coeficiente c: "))

        if a == 0:
            print("Esta equacao nao e do segundo grau.")
            return

        delta = b**2 - 4 * a * c

        if delta < 0:
            print("Esta equacao nao possui raizes reais")
        else:
            x1 = (-b + math.sqrt(delta)) / (2 * a)
            x2 = (-b - math.sqrt(delta)) / (2 * a)
            print(f"X1 = {x1:.4f}")
            print(f"X2 = {x2:.4f}")
    except ValueError:
        print("Entrada inválida. Por favor, digite números.")


def problema3_menor_de_tres():
    """Lê três números inteiros e exibe o menor deles."""
    print("\n--- Problema 3: Menor de Três  ---")
    try:
        v1 = int(input("Primeiro valor: "))
        v2 = int(input("Segundo valor: "))
        v3 = int(input("Terceiro valor: "))
        menor = min(v1, v2, v3)
        print(f"MENOR = {menor}")
    except ValueError:
        print("Entrada inválida. Por favor, digite números inteiros.")


def problema4_plano_telefonia():
    """Calcula o valor da conta de telefone com base nos minutos."""
    print("\n--- Problema 4: Plano de Telefonia  ---")
    try:
        minutos = int(input("Digite a quantidade de minutos: "))
        if minutos <= 100:
            valor_a_pagar = 50.0
        else:
            minutos_excedentes = minutos - 100
            valor_a_pagar = 50.0 + (minutos_excedentes * 2.0)
        print(f"Valor a pagar: R$ {valor_a_pagar:.2f}")
    except ValueError:
        print("Entrada inválida. Por favor, digite um número inteiro de minutos.")


def problema5_troco_ou_falta():
    """Calcula o troco de uma venda ou informa o valor faltante."""
    print("\n--- Problema 5: Troco ou Falta  ---")
    try:
        preco_unitario = float(input("Preço unitário do produto: "))
        quantidade = int(input("Quantidade comprada: "))
        dinheiro_recebido = float(input("Dinheiro recebido: "))
        total_a_pagar = preco_unitario * quantidade

        if dinheiro_recebido >= total_a_pagar:
            troco = dinheiro_recebido - total_a_pagar
            print(f"TROCO = {troco:.2f}")
        else:
            falta = total_a_pagar - dinheiro_recebido
            print(f"DINHEIRO INSUFICIENTE. FALTAM {falta:.2f} REAIS")
    except ValueError:
        print("Entrada inválida. Por favor, digite números.")


def problema6_medidor_glicose():
    """Classifica o nível de glicose no sangue."""
    print("\n--- Problema 6: Medidor de Glicose  ---")
    try:
        glicose = float(input("Digite a medida da glicose: "))
        if glicose <= 100:
            classificacao = "normal"
        elif glicose <= 140:
            classificacao = "elevado"
        else:
            classificacao = "diabetes"
        print(f"Classificacao: {classificacao}")
    except ValueError:
        print("Entrada inválida. Por favor, digite um número.")


def problema7_lancamento_dardo():
    """Informa a maior distância entre três lançamentos de dardo."""
    print("\n--- Problema 7: Lançamento de Dardo  ---")
    try:
        print("Digite as tres distancias:")
        d1 = float(input())
        d2 = float(input())
        d3 = float(input())
        maior_distancia = max(d1, d2, d3)
        print(f"MAIOR DISTANCIA = {maior_distancia:.2f}")
    except ValueError:
        print("Entrada inválida. Por favor, digite números.")


def problema8_conversor_temperatura():
    """Converte temperaturas entre Celsius e Fahrenheit."""
    print("\n--- Problema 8: Conversor de Temperatura  ---")
    escala = input("Voce vai digitar a temperatura em qual escala (C/F)? ")
    try:
        if escala.upper() == 'F':
            temp_f = float(input("Digite a temperatura em Fahrenheit: "))
            temp_c = 5/9 * (temp_f - 32)
            print(f"Temperatura equivalente em Celsius: {temp_c:.2f}")
        elif escala.upper() == 'C':
            temp_c = float(input("Digite a temperatura em Celsius: "))
            temp_f = temp_c * 9/5 + 32
            print(f"Temperatura equivalente em Fahrenheit: {temp_f:.2f}")
        else:
            print("Escala inválida.")
    except ValueError:
        print("Entrada inválida. Por favor, digite um número para a temperatura.")


def problema9_lanchonete():
    """Calcula o valor a ser pago por um lanche."""
    print("\n--- Problema 9: Lanchonete  ---")
    precos = {1: 5.00, 2: 3.50, 3: 4.80, 4: 8.90, 5: 7.32}
    try:
        codigo = int(input("Codigo do produto comprado: "))
        quantidade = int(input("Quantidade comprada: "))
        preco_unitario = precos.get(codigo, 0)
        if preco_unitario == 0:
            print("Código de produto inválido.")
        else:
            valor_a_pagar = preco_unitario * quantidade
            print(f"Valor a pagar: R$ {valor_a_pagar:.2f}")
    except ValueError:
        print("Entrada inválida. Código e quantidade devem ser números inteiros.")


def problema10_multiplos():
    """Verifica se um número é múltiplo do outro."""
    print("\n--- Problema 10: Múltiplos  ---")
    try:
        print("Digite dois numeros inteiros:")
        n1 = int(input())
        n2 = int(input())
        if n1 == 0 or n2 == 0:
             print("Sao multiplos")
        elif n1 % n2 == 0 or n2 % n1 == 0:
            print("Sao multiplos")
        else:
            print("Nao sao multiplos")
    except ValueError:
        print("Entrada inválida. Por favor, digite números inteiros.")


def problema11_aumento_salarial():
    """Calcula o novo salário com base em faixas de aumento."""
    print("\n--- Problema 11: Aumento Salarial  ---")
    try:
        salario = float(input("Digite o salario da pessoa: "))
        if salario <= 1000.00:
            percentual = 20
        elif salario <= 3000.00:
            percentual = 15
        elif salario <= 8000.00:
            percentual = 10
        else:
            percentual = 5
        aumento = salario * (percentual / 100)
        novo_salario = salario + aumento
        print(f"Novo salario R$ {novo_salario:.2f}")
        print(f"Aumento R$ {aumento:.2f}")
        print(f"Porcentagem = {percentual}%")
    except ValueError:
        print("Entrada inválida. Por favor, digite um número.")


def problema12_duracao_jogo():
    """Calcula a duração de um jogo em horas."""
    print("\n--- Problema 12: Duração do Jogo  ---")
    try:
        hora_inicial = int(input("Hora inicial: "))
        hora_final = int(input("Hora final: "))
        if hora_final > hora_inicial:
            duracao = hora_final - hora_inicial
        else:
            duracao = 24 - hora_inicial + hora_final
        print(f"O JOGO DUROU {duracao} HORA(S)")
    except ValueError:
        print("Entrada inválida. As horas devem ser números inteiros.")


def problema13_coordenadas():
    """Determina a localização de um ponto no plano cartesiano."""
    print("\n--- Problema 13: Coordenadas Cartesianas  ---")
    try:
        x = float(input("Valor de X: "))
        y = float(input("Valor de Y: "))
        if x == 0.0 and y == 0.0:
            print("Origem")
        elif x == 0.0:
            print("Eixo Y")
        elif y == 0.0:
            print("Eixo X")
        elif x > 0 and y > 0:
            print("Q1")
        elif x < 0 and y > 0:
            print("Q2")
        elif x < 0 and y < 0:
            print("Q3")
        else:
            print("Q4")
    except ValueError:
        print("Entrada inválida. Por favor, digite números.")

#----------------------------------------------------
# FUNÇÃO PRINCIPAL (MENU)
#----------------------------------------------------

def main():
    """Exibe um menu para o usuário escolher qual problema executar."""
    while True:
        print("\n" + "="*40)
        print("   LISTA DE EXERCÍCIOS CONDICIONAIS   ")
        print("="*40)
        print("1. Notas")
        print("2. Fórmula de Bhaskara")
        print("3. Menor de Três")
        print("4. Plano de Telefonia")
        print("5. Troco ou Falta")
        print("6. Medidor de Glicose")
        print("7. Lançamento de Dardo")
        print("8. Conversor de Temperatura")
        print("9. Lanchonete")
        print("10. Múltiplos")
        print("11. Aumento Salarial")
        print("12. Duração do Jogo")
        print("13. Coordenadas Cartesianas")
        print("0. Sair")
        print("="*40)

        escolha = input("Escolha um problema para executar (0-13): ")

        if escolha == '1':
            problema1_notas()
        elif escolha == '2':
            problema2_bhaskara()
        elif escolha == '3':
            problema3_menor_de_tres()
        elif escolha == '4':
            problema4_plano_telefonia()
        elif escolha == '5':
            problema5_troco_ou_falta()
        elif escolha == '6':
            problema6_medidor_glicose()
        elif escolha == '7':
            problema7_lancamento_dardo()
        elif escolha == '8':
            problema8_conversor_temperatura()
        elif escolha == '9':
            problema9_lanchonete()
        elif escolha == '10':
            problema10_multiplos()
        elif escolha == '11':
            problema11_aumento_salarial()
        elif escolha == '12':
            problema12_duracao_jogo()
        elif escolha == '13':
            problema13_coordenadas()
        elif escolha == '0':
            print("Saindo do programa. Até mais!")
            break
        else:
            print("Opção inválida. Por favor, escolha um número entre 0 e 13.")
        
        input("\nPressione Enter para continuar...")


if __name__ == "__main__":
    main()